package com.lifeplanner.auth.service;

import com.lifeplanner.auth.dto.AuthRequests;
import com.lifeplanner.auth.model.RefreshToken;
import com.lifeplanner.auth.model.User;
import com.lifeplanner.auth.repo.RefreshTokenRepository;
import com.lifeplanner.auth.repo.UserRepository;
import com.lifeplanner.auth.security.JwtUtils;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final JwtUtils jwtUtils;

    public AuthService(UserRepository userRepository, RefreshTokenRepository refreshTokenRepository, JwtUtils jwtUtils) {
        this.userRepository = userRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.jwtUtils = jwtUtils;
    }

    public User signup(AuthRequests.Signup req) {
        Optional<User> exists = userRepository.findByEmail(req.getEmail());
        if (exists.isPresent()) {
            throw new RuntimeException("email_exists");
        }
        String hashed = BCrypt.hashpw(req.getPassword(), BCrypt.gensalt());
        User u = User.builder()
                .email(req.getEmail())
                .passwordHash(hashed)
                .name(req.getName())
                .build();
        return userRepository.save(u);
    }

    public TokenPair login(AuthRequests.Login req) {
        User user = userRepository.findByEmail(req.getEmail()).orElseThrow(() -> new RuntimeException("invalid_credentials"));
        if (!BCrypt.checkpw(req.getPassword(), user.getPasswordHash())) {
            throw new RuntimeException("invalid_credentials");
        }
        UUID refreshId = UUID.randomUUID();
        RefreshToken rt = RefreshToken.builder()
                .id(refreshId)
                .userId(user.getId())
                .expiresAt(OffsetDateTime.now().plusDays(30))
                .build();
        refreshTokenRepository.save(rt);
        String refreshToken = jwtUtils.generateRefreshToken(refreshId, user.getId());
        String accessToken = jwtUtils.generateAccessToken(user.getId(), user.getEmail());
        return new TokenPair(accessToken, refreshToken);
    }

    public TokenPair refresh(String refreshToken) {
        try {
            var claims = jwtUtils.parseRefreshToken(refreshToken);
            UUID tokenId = UUID.fromString(claims.getBody().getId());
            RefreshToken rt = refreshTokenRepository.findById(tokenId).orElseThrow(() -> new RuntimeException("invalid_refresh"));
            if (rt.getExpiresAt().isBefore(OffsetDateTime.now())) {
                refreshTokenRepository.deleteById(tokenId);
                throw new RuntimeException("refresh_expired");
            }
            // rotate
            refreshTokenRepository.deleteById(tokenId);
            UUID newId = UUID.randomUUID();
            RefreshToken newRt = RefreshToken.builder()
                    .id(newId)
                    .userId(rt.getUserId())
                    .expiresAt(OffsetDateTime.now().plusDays(30))
                    .build();
            refreshTokenRepository.save(newRt);
            String newRefreshToken = jwtUtils.generateRefreshToken(newId, newRt.getUserId());
            // fetch user
            User user = userRepository.findById(newRt.getUserId()).orElseThrow();
            String newAccessToken = jwtUtils.generateAccessToken(user.getId(), user.getEmail());
            return new TokenPair(newAccessToken, newRefreshToken);
        } catch (Exception e) {
            throw new RuntimeException("invalid_refresh");
        }
    }

    public void logout(String refreshToken) {
        try {
            var claims = jwtUtils.parseRefreshToken(refreshToken);
            UUID tokenId = UUID.fromString(claims.getBody().getId());
            refreshTokenRepository.deleteById(tokenId);
        } catch (Exception e) {
            // ignore
        }
    }

    public record TokenPair(String accessToken, String refreshToken) {}
}
