package com.lifeplanner.auth.service;

import com.lifeplanner.auth.model.User;
import com.lifeplanner.auth.repo.UserRepository;
import com.lifeplanner.auth.security.JwtUtils;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class AuthServiceHelpers {

    private final UserRepository userRepository;
    private final JwtUtils jwtUtils;

    public AuthServiceHelpers(UserRepository userRepository, JwtUtils jwtUtils) {
        this.userRepository = userRepository;
        this.jwtUtils = jwtUtils;
    }

    public JwtUtils jwtUtils() {
        return jwtUtils;
    }

    public User getUserById(UUID id) {
        return userRepository.findById(id).orElse(null);
    }
}
