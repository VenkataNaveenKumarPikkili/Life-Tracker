package com.lifeplanner.auth.controller;

import com.lifeplanner.auth.dto.AuthRequests;
import com.lifeplanner.auth.dto.AuthResponses;
import com.lifeplanner.auth.model.User;
import com.lifeplanner.auth.service.AuthService;
import com.lifeplanner.auth.service.AuthServiceHelpers;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final AuthServiceHelpers helpers;

    public AuthController(AuthService authService, AuthServiceHelpers helpers) {
        this.authService = authService;
        this.helpers = helpers;
    }

    @PostMapping("/signup")
    public ResponseEntity<?> signup(@Valid @RequestBody AuthRequests.Signup req) {
        try {
            User u = authService.signup(req);
            return ResponseEntity.status(201).body(u);
        } catch (RuntimeException e) {
            return ResponseEntity.status(409).body(new ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody AuthRequests.Login req) {
        try {
            var tokens = authService.login(req);
            return ResponseEntity.ok(new AuthResponses.Tokens(tokens.accessToken(), tokens.refreshToken()));
        } catch (RuntimeException e) {
            return ResponseEntity.status(401).body(new ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@RequestBody RefreshRequest req) {
        try {
            var tokens = authService.refresh(req.refreshToken);
            return ResponseEntity.ok(new AuthResponses.Tokens(tokens.accessToken(), tokens.refreshToken()));
        } catch (RuntimeException e) {
            return ResponseEntity.status(401).body(new ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestBody RefreshRequest req) {
        authService.logout(req.refreshToken);
        return ResponseEntity.ok().body(java.util.Map.of("ok", true));
    }

    @GetMapping("/me")
    public ResponseEntity<?> me(@RequestHeader(value = "Authorization", required = false) String authHeader) {
        try {
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(401).body(new ErrorResponse("missing_token"));
            }
            String token = authHeader.substring(7);
            var claims = helpers.jwtUtils().parseAccessToken(token);
            String userId = claims.getBody().getSubject();
            java.util.UUID uid = java.util.UUID.fromString(userId);
            var user = helpers.getUserById(uid);
            if (user == null) return ResponseEntity.status(404).body(new ErrorResponse("not_found"));
            return ResponseEntity.ok(user);
        } catch (Exception e) {
            return ResponseEntity.status(401).body(new ErrorResponse("invalid_token"));
        }
    }

    public static class RefreshRequest {
        public String refreshToken;
    }

    public record ErrorResponse(String error) {}

}
