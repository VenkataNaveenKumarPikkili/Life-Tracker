from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from .database import SessionLocal, engine, Base
from . import models, crud, schemas, deps

# create DB tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Habit Service (FastAPI)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173", "http://localhost:*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/habit/create", response_model=schemas.HabitOut)
def create_habit(h: schemas.HabitCreate, db: Session = Depends(get_db), user = Depends(deps.get_current_user)):
    # set user_id from token
    h.user_id = user["id"]
    return crud.create_habit(db, h)

@app.get("/habit/all", response_model=list[schemas.HabitOut])
def list_habits(db: Session = Depends(get_db), user = Depends(deps.get_current_user)):
    return crud.get_habits_for_user(db, user["id"])

@app.put("/habit/update/{habit_id}", response_model=schemas.HabitOut)
def update_habit(habit_id: str, h: schemas.HabitUpdate, db: Session = Depends(get_db), user = Depends(deps.get_current_user)):
    habit = crud.get_habit(db, habit_id)
    if not habit or str(habit.user_id) != str(user["id"]):
        raise HTTPException(status_code=404, detail="Habit not found")
    return crud.update_habit(db, habit, h)

@app.delete("/habit/delete/{habit_id}", status_code=204)
def delete_habit(habit_id: str, db: Session = Depends(get_db), user = Depends(deps.get_current_user)):
    habit = crud.get_habit(db, habit_id)
    if not habit or str(habit.user_id) != str(user["id"]):
        raise HTTPException(status_code=404, detail="Habit not found")
    crud.delete_habit(db, habit)
    return None

@app.get("/health")
def health():
    return {"status": "ok"}
