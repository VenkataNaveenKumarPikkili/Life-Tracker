import { Line } from "react-chartjs-2";
import { Pie } from "react-chartjs-2";
import "../styles/analytics.css";

export default function AnalyticsDashboard({ habits }) {

  // ----------------📊 Monthly Completion Chart --------------------
  const days = [...Array(30)].map((_, i) => i + 1);
  const dailyCompletion = days.map(d =>
    habits.filter(h => h.history?.includes(`2025-11-${String(d).padStart(2, "0")}`)).length
  );

  const lineData = {
    labels: days,
    datasets: [
      {
        label: "Daily Completion %",
        data: dailyCompletion.map(v => (v / habits.length) * 100),
        borderWidth: 3,
        borderColor: "#10b981",
        fill: false,
        tension: 0.3,
        pointRadius: 4,
      }
    ]
  };

  // ----------------📅 Weekly Breakdown ----------------------------
  const weeklyStats = [1,2,3,4].map(w => {
    const start = (w - 1) * 7 + 1;
    const end = w * 7;
    const completed = dailyCompletion.slice(start-1,end).reduce((a,b)=>a+b,0)
    return Math.round((completed / (habits.length*7)) * 100 || 0);
  });

  // ----------------🔥 Motivational Score ---------------------------
  const motivation = Math.round((weeklyStats.reduce((a,b)=>a+b,0)/4));

  // ----------------🥧 Category Pie Chart ---------------------------
  const categoryCounts = {};
  habits.forEach(h=> categoryCounts[h.category] = (categoryCounts[h.category]||0)+1);
  const pieData = {
    labels: Object.keys(categoryCounts),
    datasets:[{
      data: Object.values(categoryCounts),
      backgroundColor:["#3b82f6","#10b981","#f97316","#ef4444","#8b5cf6"],
      borderWidth:0
    }]
  };

  return (
    <div className="analytics-container">

      {/* ROW 1 → Chart + Export Button */}
      <div className="chart-card">
        <div className="head-row">
          <h2>📈 Monthly Productivity</h2>
          <button className="export-btn">Export CSV / Sheets</button>
        </div>
        <Line data={lineData}/>
      </div>

      {/* ROW 2 → WEEK STATS + MOTIVATION + PIE */}
      <div className="grid-3">

        <div className="stat-card">
          <h3>Weekly Progress Breakdown</h3>
          {weeklyStats.map((w,i)=>
            <div key={i} className="week-row">
              <span>Week {i+1}</span>
              <div className="bar">
                <div className="fill" style={{width:`${w}%`}}></div>
              </div>
              <span>{w}%</span>
            </div>
          )}
        </div>

        <div className="motivation-card">
          <h3>🔥 Motivational Score</h3>
          <h1 className="score">{motivation}</h1>
          <p>Based on last 7 days activity</p>
        </div>

        <div className="pie-card">
          <h3>Category Focus</h3>
          <Pie data={pieData}/>
        </div>

      </div>
    </div>
  );
}
