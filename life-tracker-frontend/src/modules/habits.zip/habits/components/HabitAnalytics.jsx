/**  🔥 CLEAN FINAL ANALYTICS UI  */
import { Line, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend, ArcElement);

export default function HabitAnalytics({ habits, month, year, weeklyTarget }) {

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const makeIso = (d) => `${year}-${String(month + 1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;

  /** ▪ Daily % Calculation */
  const dailyPercent = days.map(d => {
    const iso = makeIso(d);
    const count = habits.filter(h => h.history?.includes(iso)).length;
    return Math.round((count / habits.length) * 100) || 0;
  });

  const chartData = {
    labels: days,
    datasets: [{
      label: "Daily Completion %",
      data: dailyPercent,
      borderColor:"#10B981",
      backgroundColor:"rgba(16,185,129,0.15)",
      borderWidth:3,
      tension:.4
    }]
  };

  /** ▪ Weekly Breakdown */
  const weekly = [0,7,14,21].map(w =>{
    const slice=dailyPercent.slice(w,w+7);
    return slice.length ? Math.round(slice.reduce((a,b)=>a+b,0)/slice.length) : 0;
  });

  /** ▪ Motivational Score */
  let last7=0;
  const lastWeekIso = [...Array(7)].map((_,i)=>{
    const d=new Date(); d.setDate(d.getDate()-(6-i));
    return d.toISOString().slice(0,10)
  });
  habits.forEach(h=> last7+=h.history?.filter(x=>lastWeekIso.includes(x)).length ||0);
  const possible=habits.length*weeklyTarget;
  const motivation=Math.round(((last7/possible)||0)*100);
  const mood= motivation>80?"🔥On Fire": motivation>60?"💪Strong": motivation>40?"✨Warmup":"Getting Started";

  /** ▪ Category Pie Data */
  const categories={};
  habits.forEach(h=> categories[h.category||"General"]=(categories[h.category]||0)+1);
  const pie = {
    labels:Object.keys(categories),
    datasets:[{ data:Object.values(categories), backgroundColor:["#0EA5E9","#22C55E","#F97316","#6366F1","#EC4899"] }]
  };

  /** ▪ AI-like Insights */
  const insight=[];
  if(habits.length){
    const best = habits.sort((a,b)=> b.history?.length-(a.history?.length||0))[0];
    insight.push(`Most consistent habit → **${best.name}**`);
    if(motivation<40) insight.push("Try reducing habit count for 1 week.");
    if(motivation>60) insight.push("Increase intensity — you're consistent!");
  }

  /** ▪ CSV EXPORT */
  const exportCSV = ()=>{
    const rows = habits.map(h=>[
      h.name,h.category,...days.map(d=>h.history?.includes(makeIso(d))?1:0)
    ].join(','));
    const blob=new Blob([["Habit,Category,",days.join(",")+"\n",...rows].join("\n")]); 
    const a=document.createElement("a"); 
    a.href=URL.createObjectURL(blob); 
    a.download="habits.csv"; a.click();
  }

  return(
    <div className="analytics-container">

      <div className="analytics-header">
        <h2>📊 Monthly Productivity</h2>
        <button onClick={exportCSV}>Export CSV → Google Sheets</button>
      </div>

      <div className="chart-box"><Line data={chartData}/></div>

      {/* 3-Panel Wrapped Analytics */}
      <div className="grid-analytics">

        <div className="card">
          <h3>Weekly Progress</h3>
          {weekly.map((v,i)=>(
            <div key={i} className="bar-row">
              <span>Week {i+1}</span>
              <div className="bar"><div style={{width:`${v}%`}}/></div>
              <b>{v}%</b>
            </div>
          ))}
        </div>

        <div className="card center">
          <h3>Motivational Score</h3>
          <div className="big-score">{motivation}</div>
          <p>{mood}</p>
        </div>

        <div className="card">
          <h3>Category Focus</h3>
          <div className="doughnut-box"><Doughnut data={pie}/></div>
        </div>

      </div>

      <div className="insight-box">
        <h3>🤖 Habit Insights</h3>
        <ul>{insight.map((x,i)=><li key={i}>{x}</li>)}</ul>
      </div>

    </div>
  );
}
