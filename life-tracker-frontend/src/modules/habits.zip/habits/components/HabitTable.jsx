import "../styles/table.css";

export default function HabitTable({ habits, month, year, toggle, remove }) {
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const makeIso = (day) => {
    const m = String(month + 1).padStart(2, "0");
    const d = String(day).padStart(2, "0");
    return `${year}-${m}-${d}`;
  };

  return (
    <div className="habit-table">
      <table>
        <thead>
          <tr>
            <th>Habit</th>
            {days.map((d) => (
              <th key={d}>{d}</th>
            ))}
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {habits.map((h) => {
            const doneCount = h.history?.length || 0;
            const percent = ((doneCount / daysInMonth) * 100).toFixed(0);

            return (
              <tr key={h.id}>
                <td className="habit-title">
                  <span className="habit-icon">{h.icon}</span>
                  <div className="habit-title-main">
                    <span>{h.name}</span>
                    <span className="habit-category-pill">
                      {h.category || "General"}
                    </span>
                  </div>
                  <span className="percent-tag">{percent}%</span>
                </td>

                {days.map((d) => {
                  const iso = makeIso(d);
                  const done = h.history?.includes(iso);

                  return (
                    <td key={d} className="cell">
                      <label className="checkbox-wrap">
                        <input
                          type="checkbox"
                          checked={!!done}
                          onChange={() => toggle(h.id, iso)}
                        />
                        <span className="checkbox-custom">
                          {done ? "✓" : ""}
                        </span>
                      </label>
                    </td>
                  );
                })}

                <td>
                  <button className="del" onClick={() => remove(h.id)}>
                    🗑
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
        <tfoot>
          <tr className="summary-row">
            <td>Week %</td>
            <td colSpan={daysInMonth}>0%</td>
            <td></td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}
