// ===================================================
// 2) src/modules/habits/components/HabitHeatmap.jsx
// ===================================================
export default function HabitHeatmap({ habits, month, year }) {
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const totalHabits = habits.length || 1;

  const makeIso = (day) => {
    const m = String(month + 1).padStart(2, "0");
    const d = String(day).padStart(2, "0");
    return `${year}-${m}-${d}`;
  };

  const dayCounts = days.map((d) => {
    const iso = makeIso(d);
    return habits.filter((h) => h.history?.includes(iso)).length;
  });

  const maxCount = Math.max(...dayCounts, 0);
  const maxDayIndex = dayCounts.indexOf(maxCount);
  const maxDay = maxDayIndex >= 0 ? days[maxDayIndex] : null;

  const getIntensityClass = (count) => {
    if (count === 0) return "level-0";
    const ratio = count / totalHabits;
    if (ratio < 0.25) return "level-1";
    if (ratio < 0.5) return "level-2";
    if (ratio < 0.75) return "level-3";
    return "level-4";
  };

  return (
    <div className="heatmap-card">
      <div className="heatmap-header">
        <span>🔥 Monthly Heat Map</span>
      </div>

      <div className="heatmap-grid">
        {days.map((d, idx) => (
          <div key={d} className="heatmap-cell-wrapper">
            <div className={`heatmap-cell ${getIntensityClass(dayCounts[idx])}`}>
              {d}
            </div>
          </div>
        ))}
      </div>

      <p className="heatmap-footer">
        Max productive day:{" "}
        {maxDay ? `${maxDay} (${maxCount} habits done)` : "0 habits done"}
      </p>
    </div>
  );
}
