import { useState } from "react";
import useHabits from "../hooks/useHabits";
import HabitTable from "../components/HabitTable";
import HabitHeatmap from "../components/HabitHeatmap";
import HabitAnalytics from "../components/HabitAnalytics";

import "../styles/dashboard.css";  // <-- New unified CSS

export default function HabitDashboard() {

  const { habits, loading, add, remove, toggle } = useHabits();
  const [name,setName] = useState("");
  const [icon,setIcon] = useState("💧");
  const [category,setCategory] = useState("General");

  const handleAdd = () => {
    if(!name.trim()) return alert("Enter habit name");
    add(name,icon,category);
    setName("");
  };

  return (
    <div className="dashboard">

      {/* 🔥 ADD NEW HABIT BAR */}
      <div className="add-bar">
        <input value={name} placeholder="Enter habit..." onChange={e=>setName(e.target.value)} />
        <select value={icon} onChange={e=>setIcon(e.target.value)}>
          <option>💧</option><option>🔥</option><option>📚</option><option>🏋️</option>
        </select>
        <select value={category} onChange={e=>setCategory(e.target.value)}>
          <option>General</option><option>Fitness</option><option>Learning</option>
        </select>
        <button onClick={handleAdd}>+ Add</button>
      </div>


      {/* 📌 SECTION 1 = HABIT TABLE FULL WIDTH */}
      <section className="section card">
        <h2>Habits</h2>
        {loading ? <p>Loading...</p> :
          <div className="table-wrapper">
            <HabitTable habits={habits} toggle={toggle} remove={remove}/>
          </div>
        }
      </section>


      {/* 📌 SECTION 2 = HEATMAP CENTERED */}
      <section className="section card">
        <HabitHeatmap habits={habits}/>
      </section>


      {/* 📌 SECTION 3 = ANALYTICS FULL WIDTH GRID */}
      <section className="section">
        <HabitAnalytics habits={habits}/>
      </section>

    </div>
  );
}
