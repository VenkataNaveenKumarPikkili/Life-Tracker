import { useEffect, useState } from "react";
import { getHabits, addHabit, deleteHabit, toggleHabit } from "../api";

export default function useHabits() {
  const [habits, setHabits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await getHabits();
      setHabits(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
      setError("Failed to load habits");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  return {
    habits,
    loading,
    error,
    add: async (name, icon, category) => {
      if (!name?.trim()) return;
      await addHabit(name.trim(), icon, category);
      await load();
    },
    remove: async (id) => {
      await deleteHabit(id);
      await load();
    },
    toggle: async (id, date) => {
      await toggleHabit(id, date);
      await load();
    },
  };
}
